from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .script import query, qa_chain_llama2,vectorstore_LLAMA_2,process_uploaded_files, llama_model,embeddingModel

@csrf_exempt  # Note: CSRF token is disabled for simplicity
def question_answering_view(request):
    if request.method == 'POST' and request.FILES:
        question = request.POST.get('query', '')
        uploaded_files = request.FILES.getlist('files')

        # Process the uploaded files with your existing function
        documents = process_uploaded_files(uploaded_files)

        response, document_names, cosine_scores, content, pages = query(
            question,
            llama_model,  
            documents,
            embeddingModel 
        )

        cosine_scores = [float(score) for score in cosine_scores]

        # Return the response as JSON
        return JsonResponse({
            'answer': response,
            'document_names': document_names,
            'cosine_scores': cosine_scores,
            'content': content,
            'pages': pages,
        })

    return JsonResponse({'error': 'Invalid request'}, status=400)

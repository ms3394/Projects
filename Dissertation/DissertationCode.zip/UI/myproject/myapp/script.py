from langchain.embeddings import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain_community.document_loaders import PyPDFLoader
from langchain.llms import Ollama
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel



import os
import fitz
import pytesseract
import io
from PIL import Image

os.environ["PATH"] += os.pathsep + '/opt/homebrew/bin'
class Document:
    def __init__(self, page_content, metadata):
        self.page_content = page_content
        self.metadata = metadata

# Function to apply OCR to an image
def ocr_image(image):
    img = Image.open(io.BytesIO(image))
    custom_config = r'--oem 3 --psm 6'
    return pytesseract.image_to_string(img, config=custom_config).lower()

# Function to load documents and apply OCR to images within them
def load_data(folder_path):
    data = []
    for file in os.listdir(folder_path):
        if file.endswith(".pdf"):
            file_path = os.path.join(folder_path, file)
            with fitz.open(file_path) as doc:
                for page_num, page in enumerate(doc):
                    # Extract text
                    page_text = page.get_text().lower()

                    # Extract images and apply OCR
                    for img_index, img in enumerate(page.get_images(full=True)):
                        xref = img[0]
                        base_image = doc.extract_image(xref)
                        image_data = base_image["image"]
                        page_text += "\n" + ocr_image(image_data)

                    page_metadata = {'source': file_path, 'page': page_num}
                    data.append(Document(page_text, page_metadata))
    return data


def process_uploaded_files(uploaded_files):
    documents = []
    for file in uploaded_files:
        with fitz.open(stream=file.read(), filetype="pdf") as doc:
            for page_num, page in enumerate(doc):
                page_text = page.get_text()
                for img_index, img in enumerate(page.get_images(full=True)):
                    xref = img[0]
                    base_image = doc.extract_image(xref)
                    image_data = base_image["image"]
                    page_text += "\n" + ocr_image(image_data)
                page_metadata = {'source': file.name, 'page': page_num}
                documents.append(Document(page_text, page_metadata))
    return documents


documents = load_data(folder_path="/Users/meheksawhney/Desktop/UI/attached_documents")
# print(documents)
# print(len(documents))

def creating_chunks(documents):
    chunk_list = []
    for doc in documents:
        chunk_list.append(doc)

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=20)
    chunks = text_splitter.split_documents(chunk_list)

    return chunks

chuncked_documents = creating_chunks(documents)

def rank_documents_with_tfidf(query, documents):
    tfidf_vectorizer = TfidfVectorizer()
    
    # Extract text content from each document for TF-IDF vectorization
    document_texts = [doc.page_content for doc in documents]
    tfidf_vectors = tfidf_vectorizer.fit_transform(document_texts)

    query_vector = tfidf_vectorizer.transform([query])
    cosine_similarities = linear_kernel(query_vector, tfidf_vectors).flatten()

    # Rank all documents based on their cosine similarity
    ranked_document_indices = cosine_similarities.argsort()[::-1]
    ranked_documents = [(documents[i], cosine_similarities[i]) for i in ranked_document_indices]
    return ranked_documents



# Loading llama2 from Ollama
llama_model = Ollama(model="llama2:13b")

def embedding_model_LLAMA_2(model_path, normalize_embedding=True):
    return HuggingFaceEmbeddings(
        model_name=model_path,
        model_kwargs={'device':'cpu'}, # running the model on CPU
        encode_kwargs={'normalize_embeddings': normalize_embedding} # ensure this is true
    )
# Loading the Embedding Model for LLAMA-2
embeddingModel = embedding_model_LLAMA_2(model_path="all-MiniLM-L6-v2")

vectorstore_LLAMA_2 = FAISS.from_documents(chuncked_documents, embeddingModel)

qa_chain_llama2 = RetrievalQA.from_chain_type(
    llm=llama_model,
    retriever=vectorstore_LLAMA_2.as_retriever(),
    chain_type="stuff",
    return_source_documents=True,
)

# def document_to_dict(document):
#     return {
#         'page_content': document.page_content,
#         'metadata': document.metadata,
#         'keywords': document.keywords
#     }


def query(query_text, llama_model, documents, embeddingModel):
    # Get ranked documents with their cosine scores
    query_text = query_text.lower()
    tfIdf_documents = rank_documents_with_tfidf(query_text, documents)

    # Extract just the relevant documents from the tfIdf documents
    relevant_documents = [doc for doc, _ in tfIdf_documents]

    # Process only preselected documents
    relevant_chunks = creating_chunks(relevant_documents)

    vectorstore_LLAMA2 = FAISS.from_documents(relevant_chunks, embeddingModel)

    qa_chain = RetrievalQA.from_chain_type(
        llm=llama_model,
        retriever=vectorstore_LLAMA2.as_retriever(),
        chain_type="stuff",
        return_source_documents=True
    )

    # Send the query to the temp qa_chain
    response = qa_chain({'query': query_text})

    # # Perform a similarity search with the query in the chunked document vector store
    # docs_and_scores = vectorstore_LLAMA2.similarity_search_with_score(query_text)

    # # Extract cosine scores
    # cosine_scores = [score for _, score in docs_and_scores]

    cosine_scores = []
    for doc, score in tfIdf_documents[:4]:
        cosine_scores.append(score)

    # Initialize containers for page numbers and content
    content = []
    pages = []
    document_name = []

    # Process 'source_documents'
    if 'source_documents' in response:
        for doc in response['source_documents']:
            if hasattr(doc, 'metadata') and 'page' in doc.metadata:
                pages.append(doc.metadata['page'] + 1)
            if hasattr(doc, 'page_content'):
                content.append(doc.page_content)
            if hasattr(doc, 'metadata') and 'source' in doc.metadata:
                document_name.append(doc.metadata['source'])

        # Remove 'source_documents' from the response for the final output
        del response['source_documents']

    return response, list(set(document_name)), cosine_scores, content, pages if pages else "No page available"

query("Could you return the name of the documents that are related to placements?", llama_model, documents, embeddingModel)
    

# def process_query(question, files):
#     documents = load_data(files)
#     chuncked_documents = creating_chunks(documents)
#     response, cosine_scores, content, pages = query(question, qa_chain_llama2, vectorstore_LLAMA_2)
#     return response, cosine_scores, content, pages

# query("Can you tell me how many marks is section B of the ED10348 exam paper?", qa_chain_llama2, vectorstore_LLAMA_2)


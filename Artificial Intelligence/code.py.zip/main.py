import random
import statistics
from random import choice

alice_location = []
bob_location = []
candy_location = []

alice_utility = []
bob_utility = []
candy_utility = []


def cal_utility(Player_one, Player_two, Player_three):

  if (Player_one == Player_two == Player_three):
    total_utility = 8
    return total_utility
  if (Player_one == Player_two) or (Player_one == Player_three):
    total_utility = 6
    return total_utility
  if (Player_two == Player_three):
    total_utility = 12
    return total_utility

  #Calculating the Utility of Player_one with Player_two
  #Checking if Player_three is between Player_one and Player_two
  if (Player_three > Player_one
      and Player_three < Player_two) or (Player_three > Player_two
                                         and Player_three < Player_one):
    if (Player_one != 12):
      if (Player_one < Player_two):
        utility_one = (Player_one + 12) - Player_two
      else:
        utility_one = (Player_two + 12) - Player_one
    else:
      utility_one = (Player_two + 12) - Player_one
  else:
    if (Player_two > Player_one):
      utility_one = Player_two - Player_one
    else:
      utility_one = Player_one - Player_two

  #Calculating the Utility of Player_one with Player_three
  #Checking if Player_two is between Player_one and Player_three
  if (Player_two > Player_one
      and Player_two < Player_three) or (Player_two > Player_three
                                         and Player_two < Player_one):
    if (Player_one != 12):
      if (Player_one < Player_two):
        utility_two = (Player_one + 12) - Player_three
      else:
        utility_two = (Player_three + 12) - Player_one
    else:
      utility_two = (Player_three + 12) - Player_one
  else:
    if (Player_three > Player_one):
      utility_two = Player_three - Player_one
    else:
      utility_two = Player_one - Player_three

  total_utility = utility_one + utility_two
  return total_utility


def strategy_for_candy():
  #Highest Probability Value of Bob
  bob_frequent_value = statistics.mode(bob_location)

  #Highest Probability Value of Alice
  alice_frequent_value = statistics.mode(alice_location)

  if (bob_frequent_value == alice_frequent_value):
    exclude_this = [bob_frequent_value]
    #randomly generating a new value that doesn't contain the most frequent value
    candy_value = choice(list(set(range(1, 12)) - set(exclude_this)))
  else:
    if (bob_frequent_value > alice_frequent_value):
      value_one = bob_frequent_value - alice_frequent_value
      value_two = (12 + alice_frequent_value) - bob_frequent_value
      if (value_one > value_two):
        equidistant_value = value_one // 2
        candy_value = bob_frequent_value - equidistant_value
      else:
        equidistant_value = value_two // 2
        candy_value = bob_frequent_value + equidistant_value
    else:
      value_one = alice_frequent_value - bob_frequent_value
      value_two = (12 + bob_frequent_value) - alice_frequent_value
      if (value_one > value_two):
        equidistant_value = value_one // 2
        candy_value = alice_frequent_value - equidistant_value
      else:
        equidistant_value = value_two // 2
        candy_value = alice_frequent_value + equidistant_value

      if (candy_value > 12):
        candy_value = candy_value - 12
  return candy_value


def strategy_for_bob(current_candy_location, strategy_number):
  #Co-operative Strategy
  if (strategy_number == 1):
    random_value = random.choice([2, 3, 4])
    bob_value = current_candy_location + random_value
    if (bob_value > 12):
      bob_value = bob_value - 12
    if (bob_value == current_candy_location):
      bob_value = current_candy_location + 6  #applying the maximum distance
      if (bob_value > 12):
        bob_value = bob_value - 12

  #Non-cooperative Strategy
  if (strategy_number == 2):
    if (max(alice_utility) <= max(candy_utility)) and (max(candy_utility) >=
                                                       max(bob_utility)):
      #Retrieving the position of the maximum utility for Candy
      candy_max = candy_location[candy_utility.index(max(candy_utility))]
      bob_value = candy_max

    if (max(alice_utility) <= max(bob_utility)) and (max(candy_utility) <
                                                     max(bob_utility)):
      #Retrieving the position of the maximum utility for Bob
      bob_max = bob_location[bob_utility.index(max(bob_utility))]
      bob_value = bob_max

    if (max(alice_utility) > max(candy_utility)) and (max(alice_utility) >
                                                      max(bob_utility)):
      #Retrieving the position of the maximum utility for Alice
      alice_max = alice_location[alice_utility.index(max(alice_utility))]
      bob_value = alice_max

    if (bob_value > 12):
      bob_value = bob_value - 12
  return bob_value


def strategy_for_alice():
  #Most Frequent Value of Bob
  current_bob_location = statistics.mode(bob_location)

  #Most Frequent Value of of Candy
  current_candy_location = statistics.mode(candy_location)

  if (current_bob_location == current_candy_location):
    exclude_this = [current_bob_location]
    #randomly generating a new value that doesn't contain the most frequent value
    alice_value = choice(list(set(range(1, 12)) - set(exclude_this)))
  else:
    #checking to see if the positions can be led to a Nash Equlibrium
    if ((current_bob_location - current_candy_location) == 4):
      alice_value = (current_bob_location + 4)
    elif ((current_candy_location - current_bob_location) == -4):
      alice_value = (current_candy_location + 4)
    else:
      if (current_bob_location > current_candy_location):
        current_distance_one = current_bob_location - current_candy_location
        current_distance_two = (current_candy_location +
                                12) - current_bob_location
        if (current_distance_one > current_distance_two):
          if (current_distance_two >= 3):
            alice_value = current_candy_location + 2
          else:
            alice_value = current_bob_location + 3
        else:
          if (current_distance_one >= 3):
            alice_value = current_candy_location + 2
          else:
            alice_value = current_bob_location + 3
      else:
        current_distance_one = current_candy_location - current_bob_location
        current_distance_two = (current_bob_location +
                                12) - current_candy_location
        if (current_distance_one > current_distance_two):
          if (current_distance_two >= 3):
            alice_value = current_bob_location + 2
          else:
            alice_value = current_candy_location + 3
        else:
          if (current_distance_one >= 3):
            alice_value = current_bob_location + 2
          else:
            alice_value = current_candy_location + 3

    if (alice_value > 12):
      alice_value = alice_value - 12
  return alice_value


def main():
  candy_sum = 0
  bob_sum = 0
  alice_sum = 0
  count_candy = 0
  count_bob = 0
  count_alice = 0
  count_equi = 0
  for x in range(100):
    #creating a history for the players
    if x <= 4:
      alice_location.append(random.randint(1, 12))
      candy_location.append(random.randint(1, 12))
      bob_location.append(random.randint(1, 12))
    else:
      candy_location.append(strategy_for_candy())
      #Updating Bob's strategies if there is a constant loss after 20 iterations
      if (count_bob <= 10) and (x >= 20):
        bob_location.append(strategy_for_bob(candy_location[x - 1], 1))
      else:
        bob_location.append(strategy_for_bob(candy_location[x - 1], 2))

      alice_location.append(strategy_for_alice())

    candy_utility.append(
      cal_utility(candy_location[x - 1], alice_location[x - 1],
                  bob_location[x - 1]))
    alice_utility.append(
      cal_utility(alice_location[x - 1], bob_location[x - 1],
                  candy_location[x - 1]))
    bob_utility.append(
      cal_utility(bob_location[x - 1], alice_location[x - 1],
                  candy_location[x - 1]))

    #To check the number of times candy is wining
    if (candy_utility[x - 1] > bob_utility[x - 1]) and (alice_utility[x - 1] <
                                                        candy_utility[x - 1]):
      count_candy += 1
    #To check the number of times bob is wining
    if (candy_utility[x - 1] > bob_utility[x - 1]) and (alice_utility[x - 1] >
                                                        bob_utility[x - 1]):
      count_bob += 1
    #To check the number of times alice is wining
    if (candy_utility[x - 1] <
        alice_utility[x - 1]) and (alice_utility[x - 1] > bob_utility[x - 1]):
      count_alice += 1

    #To check the number of times an equlibrium occurs
    if (candy_utility[x - 1] == bob_utility[x - 1] == alice_utility[x - 1]):
      count_equi += 1

    #Sum of utilities for Candy
    candy_sum += candy_utility[x - 1]

    #Sum of utilites for Bob
    bob_sum += bob_utility[x - 1]

    #Sum of utilites for Alice
    alice_sum += alice_utility[x - 1]

  #print("Number of times of players reach an equlibrium:", count_equi)

  #print("candy wins", count_candy)
  #print("bob wins", count_bob)
  #print("alice wins", count_alice)

  print("Sum of the utilies for player one (Candy):", candy_sum)
  print("Sum of the utilies for player two (Bob):", bob_sum)
  print("Sum of the utilies for player three (Alice):", alice_sum)


main()
